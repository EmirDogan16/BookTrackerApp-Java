import java.sql.*;

public class SQLManager {
    private String dbUrl;

    // Constructor accepting the database URL
    public SQLManager(String dbUrl) {
        this.dbUrl = dbUrl;
    }

    // Obtain a database connection
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl);
    }

    // Initialize the database by creating the User and ReadingHabit tables.
    // Note: User table is created with the "Name" column.
    public void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.setQueryTimeout(30);

            // Create User table with userID, age, gender, and Name columns
            String createUserTable = "CREATE TABLE IF NOT EXISTS User ("
                    + "userID INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "age INTEGER, "
                    + "gender TEXT, "
                    + "Name TEXT"
                    + ");";
            stmt.executeUpdate(createUserTable);

            // Create ReadingHabit table with habitID, book, pagesRead, submissionMoment, and user (foreign key)
            String createReadingHabitTable = "CREATE TABLE IF NOT EXISTS ReadingHabit ("
                    + "habitID INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "book TEXT, "                   // Book title/name
                    + "pagesRead INTEGER, "           // Number of pages read
                    + "submissionMoment DATETIME, "   // Record creation time
                    + "user INTEGER, "                // Foreign key referencing User(userID)
                    + "FOREIGN KEY(user) REFERENCES User(userID)"
                    + ");";
            stmt.executeUpdate(createReadingHabitTable);

            System.out.println("Database initialized with tables: User and ReadingHabit.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 1. Add a user to the database
    public void addUser(int age, String gender, String name) {
        String sql = "INSERT INTO User(age, gender, Name) VALUES(?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, age);
            pstmt.setString(2, gender);
            pstmt.setString(3, name);
            pstmt.executeUpdate();
            System.out.println("User added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2. Provide all the reading habit data for a certain user
    public void getUserReadingHabits(int userId) {
        String sql = "SELECT habitID, book, pagesRead, submissionMoment FROM ReadingHabit WHERE user = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            System.out.println("Reading habits for user " + userId + ":");
            while (rs.next()) {
                System.out.println("HabitID: " + rs.getInt("habitID")
                        + ", Book: " + rs.getString("book")
                        + ", Pages Read: " + rs.getInt("pagesRead")
                        + ", Submitted: " + rs.getString("submissionMoment"));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 3. Provide the ability to change the title of a book in the database (by habitID)
    public void updateBookTitle(int habitId, String newBookTitle) {
        String sql = "UPDATE ReadingHabit SET book = ? WHERE habitID = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newBookTitle);
            pstmt.setInt(2, habitId);
            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                System.out.println("Book title updated successfully for habitID " + habitId);
            } else {
                System.out.println("Reading habit record not found for habitID " + habitId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 4. Provide the ability to delete a record/row from the ReadingHabit table (by habitID)
    public void deleteReadingHabit(int habitId) {
        String sql = "DELETE FROM ReadingHabit WHERE habitID = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, habitId);
            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                System.out.println("Reading habit record deleted successfully.");
            } else {
                System.out.println("Reading habit record not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 5. Provide the mean age of the users
    public void showMeanAge() {
        String sql = "SELECT AVG(age) AS mean_age FROM User";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Mean age of users: " + rs.getDouble("mean_age"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 6. Provide the total number of users that have read pages from a specific book
    public void showUserCountByBook(String bookTitle) {
        String sql = "SELECT COUNT(DISTINCT user) AS user_count FROM ReadingHabit WHERE book = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, bookTitle);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("User count for book '" + bookTitle + "': " + rs.getInt("user_count"));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 7. Provide the total number of pages read by all users
    public void showTotalPagesRead() {
        String sql = "SELECT SUM(pagesRead) AS total_pages FROM ReadingHabit";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Total pages read: " + rs.getInt("total_pages"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 8. Provide the total number of users that have read more than one book
    public void showUserCountWithMultipleBooks() {
        String sql = "SELECT COUNT(*) AS user_count FROM ("
                + "SELECT user, COUNT(book) AS book_count FROM ReadingHabit GROUP BY user HAVING book_count > 1"
                + ")";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Users who have read more than one book: " + rs.getInt("user_count"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 9. Add a column to the User table named "Name" which contains TEXT data.
    // This function checks if the column exists, and if not, it adds the column.
    public void addNameColumnToUser() {
        try (Connection conn = getConnection()) {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet rs = meta.getColumns(null, null, "User", "Name");
            if (!rs.next()) {
                // Column does not exist, add it
                try (Statement stmt = conn.createStatement()) {
                    stmt.executeUpdate("ALTER TABLE User ADD COLUMN Name TEXT;");
                    System.out.println("'Name' column added to the User table.");
                }
            } else {
                System.out.println("'Name' column already exists in the User table.");
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
