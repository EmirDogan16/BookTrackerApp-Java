import java.util.Scanner;

public class BooktrackerApp {
    public static void main(String[] args) {
        // Create an instance of SQLManager using the booktracker.db database
        SQLManager sqlManager = new SQLManager("jdbc:sqlite:booktracker.db");

        // Initialize the database (creates User and ReadingHabit tables if they don't exist)
        sqlManager.initializeDatabase();

        // Command-line interface menu
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Booktracker Menu ---");
            System.out.println("1. Add a User");
            System.out.println("2. Show Reading Habit Data for a User");
            System.out.println("3. Change the Title of a Book (by habitID)");
            System.out.println("4. Delete a Reading Habit Record (by habitID)");
            System.out.println("5. Show the Mean Age of Users");
            System.out.println("6. Show Total Number of Users that have read pages from a Specific Book");
            System.out.println("7. Show Total Number of Pages Read by All Users");
            System.out.println("8. Show Total Number of Users that have read more than one book");
            System.out.println("9. Add 'Name' Column to User Table");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.print("Enter user age: ");
                    int age = Integer.parseInt(scanner.nextLine());
                    System.out.print("Enter user gender: ");
                    String gender = scanner.nextLine();
                    System.out.print("Enter user name: ");
                    String name = scanner.nextLine();
                    sqlManager.addUser(age, gender, name);
                    break;
                case "2":
                    System.out.print("Enter user ID to view reading habits: ");
                    try {
                        int uid = Integer.parseInt(scanner.nextLine());
                        sqlManager.getUserReadingHabits(uid);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid user ID. Please enter a numeric value.");
                    }
                    break;
                case "3":
                    System.out.print("Enter habitID to change the book title: ");
                    try {
                        int habitIdToUpdate = Integer.parseInt(scanner.nextLine());
                        System.out.print("Enter new book title: ");
                        String newBookTitle = scanner.nextLine();
                        sqlManager.updateBookTitle(habitIdToUpdate, newBookTitle);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid habitID. Please enter a numeric value.");
                    }
                    break;
                case "4":
                    System.out.print("Enter habitID to delete: ");
                    try {
                        int habitIdToDelete = Integer.parseInt(scanner.nextLine());
                        sqlManager.deleteReadingHabit(habitIdToDelete);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid habitID. Please enter a numeric value.");
                    }
                    break;
                case "5":
                    sqlManager.showMeanAge();
                    break;
                case "6":
                    System.out.print("Enter book title to get user count: ");
                    String countBook = scanner.nextLine();
                    sqlManager.showUserCountByBook(countBook);
                    break;
                case "7":
                    sqlManager.showTotalPagesRead();
                    break;
                case "8":
                    sqlManager.showUserCountWithMultipleBooks();
                    break;
                case "9":
                    sqlManager.addNameColumnToUser();
                    break;
                case "10":
                    exit = true;
                    System.out.println("Exiting application.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
}
